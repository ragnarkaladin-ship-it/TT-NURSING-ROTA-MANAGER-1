
import React, { useState } from 'react';
import { Nurse } from '../types';
import { User, Phone, FileText, Calendar, Save, Loader2 } from 'lucide-react';

interface ProfileCompletionFormProps {
  nurse: Nurse;
  onUpdate: (updates: Partial<Nurse>) => Promise<void>;
}

const ProfileCompletionForm: React.FC<ProfileCompletionFormProps> = ({ nurse, onUpdate }) => {
  const [formData, setFormData] = useState({
    name: nurse.name || '',
    phone: nurse.phone || '',
    nckNo: nurse.nckNo || '',
    licenseExpiry: nurse.licenseExpiry || '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      if (!formData.name || !formData.phone || !formData.nckNo || !formData.licenseExpiry) {
        throw new Error('All fields are required for professional registration.');
      }
      await onUpdate(formData);
    } catch (err: any) {
      setError(err.message || 'Failed to update profile.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-[3.5rem] shadow-2xl border border-indigo-100 overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="bg-indigo-950 p-10 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10"><FileText size={120} /></div>
          <div className="relative z-10">
            <h2 className="text-3xl font-black tracking-tighter uppercase italic flex items-center gap-3">
              <User className="text-emerald-400" />
              Practitioner Registry
            </h2>
            <p className="text-indigo-300 text-[10px] font-black uppercase tracking-[0.2em] mt-2">Initial Personnel Authentication Protocol</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-10 space-y-8">
          {error && (
            <div className="bg-red-50 text-red-600 p-5 rounded-3xl text-xs font-black border border-red-100 uppercase tracking-widest animate-pulse">
              Protocol Error: {error}
            </div>
          )}

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                <User size={14} className="text-indigo-400" /> Full Name
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-slate-50 border-2 border-slate-50 p-5 rounded-3xl outline-none focus:bg-white focus:border-indigo-600 transition-all font-bold text-slate-800"
                placeholder="e.g. Nurse Jane Doe"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                  <Phone size={14} className="text-indigo-400" /> Phone Number
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-50 p-5 rounded-3xl outline-none focus:bg-white focus:border-indigo-600 transition-all font-bold text-slate-800"
                  placeholder="+254..."
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                  <FileText size={14} className="text-indigo-400" /> NCK Reg Number
                </label>
                <input
                  type="text"
                  required
                  value={formData.nckNo}
                  onChange={(e) => setFormData({ ...formData, nckNo: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-50 p-5 rounded-3xl outline-none focus:bg-white focus:border-indigo-600 transition-all font-bold text-slate-800"
                  placeholder="NCK-XXXXX"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                <Calendar size={14} className="text-indigo-400" /> License Expiry Date
              </label>
              <input
                type="date"
                required
                value={formData.licenseExpiry}
                onChange={(e) => setFormData({ ...formData, licenseExpiry: e.target.value })}
                className="w-full bg-slate-50 border-2 border-slate-50 p-5 rounded-3xl outline-none focus:bg-white focus:border-indigo-600 transition-all font-bold text-slate-800"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-indigo-600 text-white py-6 rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 disabled:opacity-50 group"
          >
            {isSubmitting ? (
              <Loader2 className="animate-spin" size={20} />
            ) : (
              <>
                <Save size={20} className="group-hover:scale-110 transition-transform" />
                Finalize Registration
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProfileCompletionForm;
