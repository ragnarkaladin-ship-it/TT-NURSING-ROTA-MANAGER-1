
import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { Nurse, Duty, AdminUser, Message, WardType, ShiftType, UserRole } from '../types';

// Database Interface
export interface DatabaseService {
  init(): Promise<void>;
  getAdmins(): Promise<AdminUser[]>;
  getNurses(): Promise<Nurse[]>;
  getDuties(): Promise<Duty[]>;
  getMessages(): Promise<Message[]>;
  addNurse(nurse: Partial<Nurse>): Promise<Nurse>;
  addDuty(duty: Partial<Duty>): Promise<Duty>;
  addDutiesBulk(duties: Partial<Duty>[]): Promise<Duty[]>;
  addMessage(message: Partial<Message>): Promise<Message>;
  updateNurse(nurseId: string | number, update: Partial<Nurse>): Promise<Nurse>;
  updateDuty(dutyId: string | number, update: Partial<Duty>): Promise<Duty>;
  updateDutiesStatusBulk(dutyIds: (string | number)[], status: Duty['status']): Promise<void>;
  deleteDuty(dutyId: string | number): Promise<void>;
  updateMessage(messageId: string | number, update: Partial<Message>): Promise<Message>;
  login(email: string, password: string): Promise<{ user: Nurse | AdminUser; role: UserRole } | null>;
}

// Firebase Implementation
class FirebaseService implements DatabaseService {
  private db: admin.firestore.Firestore;

  constructor() {
    if (!admin.apps.length) {
      const projectId = process.env.FIREBASE_PROJECT_ID || firebaseConfig.projectId;
      admin.initializeApp({
        projectId: projectId,
        databaseURL: process.env.FIREBASE_DATABASE_URL || `https://${projectId}.firebaseio.com`
      });
    }
    // Use the databaseId from config if available
    if (firebaseConfig.firestoreDatabaseId) {
      this.db = getFirestore(admin.apps[0]!, firebaseConfig.firestoreDatabaseId);
    } else {
      this.db = getFirestore(admin.apps[0]!);
    }
  }

  async init() {
    const nurseSnapshot = await this.db.collection('nurses').limit(1).get();
    if (nurseSnapshot.empty) {
      console.log("Seeding 10 nurses per ward (Firebase)...");
      const wards: WardType[] = ['Ward 1', 'Ward 2', 'Ward 3', 'Ward 4', 'Ward 5/6', 'ICU', 'Theatre'];
      const specialties = ['General Nursing', 'Critical Care', 'Pediatrics', 'Maternity', 'Surgical', 'Emergency'];
      
      const batch = this.db.batch();
      for (const ward of wards) {
        for (let i = 1; i <= 10; i++) {
          const nurseRef = this.db.collection('nurses').doc();
          batch.set(nurseRef, {
            name: `Nurse ${i} (${ward})`,
            email: `nurse${i}.${ward.toLowerCase().replace(/[^a-z0-9]/g, '')}@tumutumu.org`,
            phone: '+254700000000',
            ward,
            specialty: specialties[Math.floor(Math.random() * specialties.length)],
            nckNo: `NCK-${Math.floor(10000 + Math.random() * 90000)}`,
            password: 'TTNURSING123'
          });
        }
      }
      await batch.commit();
    }

    // Seed Default Admin
    console.log('Initializing Firebase Service (Admin SDK)...');
    const adminEmails = [
      { email: 'tumutumuclinicmanager@gmail.com', name: 'Tumutumu Clinic Manager', role: 'cno', ward: 'All' },
      { email: 'godiimwas@gmail.com', name: 'System Admin', role: 'cno', ward: 'All' },
      { email: 'godiimwas@tumutumu.org', name: 'System Admin', role: 'cno', ward: 'All' },
      { email: 'hr@tumutumu.org', name: 'HR Manager', role: 'hr', ward: 'All' },
      { email: 'hr@tumutumu.com', name: 'HR Manager', role: 'hr', ward: 'All' },
      { email: 'admin.icu@tumutumu.org', name: 'ICU Manager', role: 'admin', ward: 'ICU' },
      { email: 'kevin.mugo@tumutumu.org', name: 'Kevin Mugo', role: 'admin', ward: 'Ward 5/6' }
    ];
    for (const admin of adminEmails) {
      console.log(`Checking admin: ${admin.email}`);
      const adminSnapshot = await this.db.collection('admins').where('email', '==', admin.email.toLowerCase()).get();
      if (adminSnapshot.empty) {
        console.log(`Seeding admin: ${admin.email} (Firebase)...`);
        await this.db.collection('admins').add({
          name: admin.name,
          email: admin.email.toLowerCase(),
          role: admin.role,
          ward: admin.ward,
          password: 'admin123'
        });
      } else {
        // Ensure password exists for existing admins
        const doc = adminSnapshot.docs[0];
        if (!doc.data().password) {
          console.log(`Updating password for existing admin: ${admin.email}`);
          await doc.ref.update({ password: 'admin123' });
        }
      }
    }

    // Seed John Thairu (Casual Worker)
    const johnEmail = 'john.thairu@tumutumu.org';
    const johnSnapshot = await this.db.collection('nurses').where('email', '==', johnEmail).get();
    if (johnSnapshot.empty) {
      console.log('Seeding John Thairu (Casual Worker)...');
      await this.db.collection('nurses').add({
        name: 'John Thairu',
        email: johnEmail,
        phone: '+254700000000',
        ward: 'Ward 5/6',
        specialty: 'Casual Worker',
        nckNo: 'CASUAL-001',
        password: 'TTNURSING123'
      });
    }
    console.log('Firebase Service initialization complete.');
  }

  async getAdmins(): Promise<AdminUser[]> {
    const snapshot = await this.db.collection('admins').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
  }

  async getNurses(): Promise<Nurse[]> {
    const snapshot = await this.db.collection('nurses').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
  }

  async getDuties(): Promise<Duty[]> {
    const snapshot = await this.db.collection('duties').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
  }

  async getMessages(): Promise<Message[]> {
    const snapshot = await this.db.collection('messages').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
  }

  async addNurse(nurse: Partial<Nurse>): Promise<Nurse> {
    const docRef = await this.db.collection('nurses').add(nurse);
    return { id: docRef.id, ...nurse } as any;
  }

  async addDuty(duty: Partial<Duty>): Promise<Duty> {
    const docRef = await this.db.collection('duties').add(duty);
    return { id: docRef.id, ...duty } as any;
  }

  async addDutiesBulk(duties: Partial<Duty>[]): Promise<Duty[]> {
    const savedDuties: Duty[] = [];
    const chunks = [];
    for (let i = 0; i < duties.length; i += 500) {
      chunks.push(duties.slice(i, i + 500));
    }

    for (const chunk of chunks) {
      const batch = this.db.batch();
      const chunkSaved: Duty[] = [];
      for (const duty of chunk) {
        const docRef = this.db.collection('duties').doc();
        batch.set(docRef, duty);
        chunkSaved.push({ id: docRef.id, ...duty } as any);
      }
      await batch.commit();
      savedDuties.push(...chunkSaved);
    }
    return savedDuties;
  }

  async addMessage(message: Partial<Message>): Promise<Message> {
    const docRef = await this.db.collection('messages').add(message);
    return { id: docRef.id, ...message } as any;
  }

  async updateNurse(nurseId: string | number, update: Partial<Nurse>): Promise<Nurse> {
    await this.db.collection('nurses').doc(nurseId.toString()).update(update);
    const doc = await this.db.collection('nurses').doc(nurseId.toString()).get();
    return { id: doc.id, ...doc.data() } as any;
  }

  async updateDuty(dutyId: string | number, update: Partial<Duty>): Promise<Duty> {
    await this.db.collection('duties').doc(dutyId.toString()).update(update);
    const doc = await this.db.collection('duties').doc(dutyId.toString()).get();
    return { id: doc.id, ...doc.data() } as any;
  }

  async updateDutiesStatusBulk(dutyIds: (string | number)[], status: Duty['status']): Promise<void> {
    const chunks = [];
    for (let i = 0; i < dutyIds.length; i += 500) {
      chunks.push(dutyIds.slice(i, i + 500));
    }

    for (const chunk of chunks) {
      const batch = this.db.batch();
      for (const id of chunk) {
        const docRef = this.db.collection('duties').doc(id.toString());
        batch.update(docRef, { status });
      }
      await batch.commit();
    }
  }

  async deleteDuty(dutyId: string | number): Promise<void> {
    await this.db.collection('duties').doc(dutyId.toString()).delete();
  }

  async updateMessage(messageId: string | number, update: Partial<Message>): Promise<Message> {
    await this.db.collection('messages').doc(messageId.toString()).update(update);
    const doc = await this.db.collection('messages').doc(messageId.toString()).get();
    return { id: doc.id, ...doc.data() } as any;
  }

  async login(email: string, password: string): Promise<{ user: Nurse | AdminUser; role: UserRole } | null> {
    const normalizedEmail = email.trim().toLowerCase();
    console.log(`FirebaseService.login attempt for: ${normalizedEmail}`);
    
    // Hardcoded bypass for critical admin accounts to ensure access
    const defaultAdmins = ['tumutumuclinicmanager@gmail.com', 'godiimwas@gmail.com', 'godiimwas@tumutumu.org', 'hr@tumutumu.org', 'hr@tumutumu.com', 'admin.icu@tumutumu.org'];
    if (defaultAdmins.includes(normalizedEmail) && password?.trim() === 'admin123') {
      console.log(`Bypass login successful for ${normalizedEmail}`);
      let role: UserRole = 'cno';
      if (normalizedEmail === 'hr@tumutumu.org' || normalizedEmail === 'hr@tumutumu.com') role = 'hr';
      if (normalizedEmail === 'admin.icu@tumutumu.org') role = 'admin';
      
      let name = 'System Admin';
      if (normalizedEmail.includes('clinicmanager')) name = 'Clinic Manager';
      else if (normalizedEmail.includes('hr')) name = 'HR Manager';
      else if (normalizedEmail.includes('admin.icu')) name = 'ICU Manager';

      return { 
        user: { 
          id: 'admin-' + normalizedEmail.split('@')[0], 
          email: normalizedEmail, 
          name: name,
          role: role,
          ward: normalizedEmail === 'admin.icu@tumutumu.org' ? 'ICU' : 'All'
        } as any, 
        role: role 
      };
    }

    // Check admins
    const adminSnapshot = await this.db.collection('admins').where('email', '==', normalizedEmail).get();
    if (!adminSnapshot.empty) {
      const doc = adminSnapshot.docs[0];
      const data = doc.data();
      console.log(`Found admin document for ${normalizedEmail}:`, { ...data, password: '***' });
      
      if (data.password === password) {
        console.log(`Admin login successful for ${normalizedEmail}`);
        return { user: { id: doc.id, ...data } as any, role: data.role };
      } else {
        console.log(`Admin login failed for ${normalizedEmail}: Password mismatch.`);
      }
    } else {
      console.log(`No admin document found for ${normalizedEmail}`);
    }

    // Check nurses
    const nurseSnapshot = await this.db.collection('nurses').where('email', '==', normalizedEmail).get();
    if (!nurseSnapshot.empty) {
      const doc = nurseSnapshot.docs[0];
      const data = doc.data();
      console.log(`Found nurse document for ${normalizedEmail}:`, { ...data, password: '***' });
      // Allow login if password matches OR if it's the default nurse password
      if (data.password === password || password === 'TTNURSING123') {
        console.log(`Nurse login successful for ${normalizedEmail}`);
        return { user: { id: doc.id, ...data } as any, role: 'nurse' };
      } else {
        console.log(`Nurse login failed for ${normalizedEmail}: Password mismatch.`);
      }
    } else {
      console.log(`No nurse document found for ${normalizedEmail}`);
    }
    return null;
  }
}

// Memory Implementation (Fallback)
class MemoryService implements DatabaseService {
  private idCounter = 1000;
  private admins: AdminUser[] = [
    { id: 1, name: 'Ward 1 Manager', email: 'admin.ward1@tumutumu.org', role: 'admin', ward: 'Ward 1' },
    { id: 2, name: 'Chief Nursing Officer', email: 'cno@tumutumu.org', role: 'cno', ward: 'All' },
    { id: 3, name: 'Tumutumu Clinic Manager', email: 'tumutumuclinicmanager@gmail.com', role: 'cno', ward: 'All' },
    { id: 4, name: 'System Admin', email: 'godiimwas@gmail.com', role: 'cno', ward: 'All' },
    { id: 5, name: 'System Admin', email: 'godiimwas@tumutumu.org', role: 'cno', ward: 'All' },
    { id: 6, name: 'HR Manager', email: 'hr@tumutumu.org', role: 'hr', ward: 'All' },
    { id: 7, name: 'HR Manager', email: 'hr@tumutumu.com', role: 'hr', ward: 'All' },
    { id: 8, name: 'ICU Manager', email: 'admin.icu@tumutumu.org', role: 'admin', ward: 'ICU' }
  ];
  private nurses: Nurse[] = [];
  private duties: Duty[] = [];
  private messages: Message[] = [];

  async init() {
    console.warn('USING MEMORY DATABASE FALLBACK. DATA WILL NOT PERSIST.');
    
    // Seed Nurses
    const wards: WardType[] = ['Ward 1', 'Ward 2', 'Ward 3', 'Ward 4', 'Ward 5/6', 'ICU', 'Theatre'];
    const specialties = ['General Nursing', 'Critical Care', 'Pediatrics', 'Maternity', 'Surgical', 'Emergency'];
    
    for (const ward of wards) {
      for (let i = 1; i <= 10; i++) {
        this.nurses.push({
          id: this.idCounter++,
          name: `Nurse ${i} (${ward})`,
          email: `nurse${i}.${ward.toLowerCase().replace(/[^a-z0-9]/g, '')}@tumutumu.org`,
          phone: '+254700000000',
          ward,
          specialty: specialties[Math.floor(Math.random() * specialties.length)],
          nckNo: `NCK-${Math.floor(10000 + Math.random() * 90000)}`,
          password: 'TTNURSING123'
        });
      }
    }
  }

  async getAdmins(): Promise<AdminUser[]> { return this.admins; }
  async getNurses(): Promise<Nurse[]> { return this.nurses; }
  async getDuties(): Promise<Duty[]> { return this.duties; }
  async getMessages(): Promise<Message[]> { return this.messages; }

  async addNurse(nurse: Partial<Nurse>): Promise<Nurse> {
    const newNurse = { ...nurse, id: this.idCounter++ } as Nurse;
    this.nurses.push(newNurse);
    return newNurse;
  }

  async addDuty(duty: Partial<Duty>): Promise<Duty> {
    const newDuty = { ...duty, id: this.idCounter++ } as Duty;
    this.duties.push(newDuty);
    return newDuty;
  }

  async addDutiesBulk(duties: Partial<Duty>[]): Promise<Duty[]> {
    const newDuties = duties.map(d => ({ ...d, id: this.idCounter++ } as Duty));
    this.duties.push(...newDuties);
    return newDuties;
  }

  async addMessage(message: Partial<Message>): Promise<Message> {
    const newMessage = { ...message, id: this.idCounter++ } as Message;
    this.messages.push(newMessage);
    return newMessage;
  }

  async updateNurse(nurseId: string | number, update: Partial<Nurse>): Promise<Nurse> {
    const idx = this.nurses.findIndex(n => n.id === nurseId);
    if (idx === -1) throw new Error('Nurse not found');
    this.nurses[idx] = { ...this.nurses[idx], ...update };
    return this.nurses[idx];
  }

  async updateDuty(dutyId: string | number, update: Partial<Duty>): Promise<Duty> {
    const idx = this.duties.findIndex(d => d.id === dutyId);
    if (idx === -1) throw new Error('Duty not found');
    this.duties[idx] = { ...this.duties[idx], ...update };
    return this.duties[idx];
  }

  async updateDutiesStatusBulk(dutyIds: (string | number)[], status: Duty['status']): Promise<void> {
    this.duties = this.duties.map(d => {
      if (dutyIds.includes(d.id)) {
        return { ...d, status };
      }
      return d;
    });
  }

  async deleteDuty(dutyId: string | number): Promise<void> {
    this.duties = this.duties.filter(d => d.id !== dutyId);
  }

  async updateMessage(messageId: string | number, update: Partial<Message>): Promise<Message> {
    const idx = this.messages.findIndex(m => m.id === messageId);
    if (idx === -1) throw new Error('Message not found');
    this.messages[idx] = { ...this.messages[idx], ...update };
    return this.messages[idx];
  }

  async login(email: string, password: string): Promise<{ user: Nurse | AdminUser; role: UserRole } | null> {
    const normalizedEmail = email.trim().toLowerCase();
    const admin = this.admins.find(a => a.email.toLowerCase() === normalizedEmail && password?.trim() === 'admin123');
    if (admin) return { user: admin, role: admin.role };
    const nurse = this.nurses.find(n => n.email.toLowerCase() === normalizedEmail && (n.password === password || password?.trim() === 'TTNURSING123'));
    if (nurse) return { user: nurse, role: 'nurse' };
    return null;
  }
}

// Factory to get the correct database service
export function getDatabaseService(): DatabaseService {
  const type = process.env.DB_TYPE || 'firebase';
  
  if (type === 'memory') {
    console.log('Using memory database.');
    return new MemoryService();
  }

  let service: DatabaseService;
  try {
    switch (type) {
      case 'firebase':
        service = new FirebaseService();
        break;
      default:
        console.warn(`Unknown or unsupported DB_TYPE: ${type}, defaulting to Firebase.`);
        service = new FirebaseService();
    }
  } catch (err) {
    console.error(`Failed to instantiate database service:`, err);
    console.warn('FALLING BACK TO MEMORY DATABASE DUE TO INSTANTIATION FAILURE.');
    return new MemoryService();
  }

  // Wrap the service with a fallback mechanism
  const originalInit = service.init.bind(service);
  service.init = async function() {
    try {
      await originalInit();
    } catch (err) {
      console.error(`Failed to initialize database:`, err);
      console.warn('FALLING BACK TO MEMORY DATABASE DUE TO INITIALIZATION FAILURE.');
      
      // Replace the service instance with MemoryService
      const memory = new MemoryService();
      await memory.init();
      
      // Monkey-patch the service methods to use memory instead
      const methods: (keyof DatabaseService)[] = [
        'getAdmins', 'getNurses', 'getDuties', 'getMessages',
        'addNurse', 'addDuty', 'addDutiesBulk', 'addMessage',
        'updateNurse', 'updateDuty', 'updateDutiesStatusBulk', 'deleteDuty', 'updateMessage',
        'login'
      ];
      
      for (const method of methods) {
        (service as any)[method] = (memory as any)[method].bind(memory);
      }
    }
  };

  return service;
}

export const db = getDatabaseService();
