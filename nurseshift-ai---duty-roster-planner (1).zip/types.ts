
export enum ShiftType {
  STRAIGHT = 'S',
  NIGHT = 'N',
  DAY = 'D',
  PUBLIC_HOLIDAY = 'PH',
  OFF = 'O',
  LEAVE = 'Leave'
}

export type WardType = 'Ward 1' | 'Ward 2' | 'Ward 3' | 'Ward 4' | 'Ward 5/6' | 'ICU' | 'Theatre' | 'All';

export interface Nurse {
  id: string | number;
  name: string;
  email: string;
  phone: string;
  ward: WardType;
  specialty: string;
  nckNo: string;
  licenseExpiry?: string; // ISO date string
  password?: string;
}

export interface AdminUser {
  id: string | number;
  name: string;
  email: string;
  role: 'admin' | 'cno' | 'hr';
  ward: WardType;
}

export interface Duty {
  id: string | number;
  nurseId: string | number;
  date: string;
  shift: ShiftType;
  status?: 'draft' | 'pending' | 'approved' | 'submitted_to_hr';
}

export interface Message {
  id: string | number;
  senderId: string | number;
  senderRole: 'admin' | 'nurse' | 'system';
  ward: WardType;
  content: string;
  timestamp: string;
  category?: 'general' | 'leave_request' | 'shift_swap';
  metadata?: {
    startDate?: string;
    endDate?: string;
    myDate?: string;
    targetDate?: string;
    targetNurse?: string;
    isProcessed?: boolean;
    status?: 'approved' | 'rejected' | 'pending';
  };
}

export type UserRole = 'admin' | 'nurse' | 'cno' | 'hr';

export interface AppState {
  currentUser: Nurse | AdminUser | null;
  role: UserRole;
  nurses: Nurse[];
  duties: Duty[];
  messages: Message[];
}
